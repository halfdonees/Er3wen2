/*
 *   Plane.cpp
 *
 *   Author: ROBOTIS
 *
 */

#include "Plane.h"

using namespace Robot;


Plane3D::Plane3D()
{
}

Plane3D::~Plane3D()
{
}
